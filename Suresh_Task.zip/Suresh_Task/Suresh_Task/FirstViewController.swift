//
//  FirstViewController.swift
//  Suresh_Task
//
//  Created by Suresh on 29/08/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import UIKit

@objc public protocol GetListDelegate:NSObjectProtocol {
    @objc optional  func onSuccesofGetList(responseDic : NSDictionary,errormsg :String,optiona : Any?)
}

class FirstViewController: ServiceEngineClass,ServiceEngineDelegate,UITableViewDelegate, UITableViewDataSource {

    var isLoggedIn:Bool = false
    var jsonArrDict = [NSDictionary]()
    var refreshControl = UIRefreshControl()
    let activityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.whiteLarge)

    @IBOutlet weak var aTableView: UITableView!

    
    @objc func refresh(_ sender: AnyObject) {
        // Code to refresh table view
    }
    
    override func viewDidLoad() {
        
        activityIndicator.center = self.view.center
        activityIndicator.color = UIColor.red
        self.view.addSubview(activityIndicator)
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        let userDefaults = UserDefaults.standard
        isLoggedIn = userDefaults.value(forKey: "LOGINSUCCESS") as? Bool ?? false
        if(!isLoggedIn){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "signupVC") as! ViewController
            self.present(vc, animated: true, completion: nil)
        }
        else{
            refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
            refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
            aTableView.addSubview(refreshControl)
            activityIndicator.startAnimating()
            self.serviceDelegate = self;
            self.getList()
        }
    }
    
    @objc private func refreshData(_ sender: Any) {
        // Fetch Weather Data
        self.serviceDelegate = self;
        self.getList()
    }
    
    // MARK: - SUCCESS OR FAILURE RESPONSE
    func onSuccesofGetList(responseDic : NSDictionary,errormsg :String,optiona : Any?) {
        if errormsg.count == 0 {
            print(responseDic["payload"] as Any)
            jsonArrDict = responseDic["payload"] as Any as! [NSDictionary]
            print(jsonArrDict)
            
            DispatchQueue.main.async {
                self.aTableView.delegate = self
                self.aTableView.dataSource = self
                self.aTableView.reloadData()
                self.activityIndicator.stopAnimating()
                self.refreshControl.endRefreshing()
            }
            
        }
        
    }
    
    // MARK: - TABLEVIEW METHODS
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jsonArrDict.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "customcell") as! CustomTableViewCell
        let jsonDict = jsonArrDict[indexPath.row]
        cell.cellTitleLabel.text = jsonDict["title"]! as? String
        cell.cellDescriptionLabel.text = jsonDict["description"]! as? String

        let imgURL = NSURL(string: jsonDict["image"]! as? String ?? "")
        let request: NSURLRequest = NSURLRequest(url: imgURL! as URL)
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest, completionHandler: {data, response, error -> Void in
                let error = error
                let data = data
                if error == nil {
                    // Convert the downloaded data in to a UIImage object
                    let image = UIImage(data: data!)
                    // Store the image in to our cache
                    // Update the cell
                    DispatchQueue.main.async {
                        if let cell: CustomTableViewCell = tableView.cellForRow(at: indexPath) as? CustomTableViewCell {
                            cell.cellImageView.image = image
                        }
                    }
                }
            })
            task.resume()
           return cell
        }
}



    

