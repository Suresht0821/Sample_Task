//
//  CustomTableViewCell.swift
//  Suresh_Task
//
//  Created by Suresh on 29/08/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var cellTitleLabel: UILabel!
    @IBOutlet weak var cellDescriptionLabel: UILabel!
    
}
