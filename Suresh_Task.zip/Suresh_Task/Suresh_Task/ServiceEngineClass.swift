//
//  ServiceEngineClass.swift
//  Suresh_Task
//
//  Created by Suresh on 29/08/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import Foundation
import UIKit

@objc public protocol ServiceEngineDelegate:NSObjectProtocol {
    @objc optional  func onSuccesofSignupService(responseDic : NSDictionary,errormsg :String,optiona : Any?)
    @objc optional  func onSuccesofGetList(responseDic : NSDictionary,errormsg :String,optiona : Any?)
}

class ServiceEngineClass:UIViewController {
    var reachability = Reachability()
    weak var serviceDelegate: ServiceEngineDelegate?
    
    //MARK : - SIGNUP Service call
    public func callSignUpService(_ sinupDic:NSMutableDictionary){
        if(reachability?.isReachable)!
        {
            
            //let parameterDictionary = ["eid" : "123456", "name" : "john", "idbarahno" : "123456", "emailaddress" : "john.smith@mbrhe.ae", "unifiednumber" : "123", "mobileno" : "971556987002"]
            let Url = String(format: "https://api.qa.mrhe.gov.ae/mrhecloud/v1.4/api/iskan/v1/certificates/towhomitmayconcern?local=en")
            guard let serviceUrl = URL(string: Url) else { return }
            let parameterDictionary = ["eid" : sinupDic.value(forKey: "EID")!, "name" : sinupDic.value(forKey: "NAME")!, "idbarahno" : sinupDic.value(forKey: "IDBARHNO")!, "emailaddress" : sinupDic.value(forKey: "EMAIL")!, "unifiednumber" : sinupDic.value(forKey: "UNIFIED")!, "mobileno" : sinupDic.value(forKey: "MOBILENO")!]
            var request = URLRequest(url: serviceUrl)
            request.httpMethod = "POST"
            request.setValue("mobile_dev_temp", forHTTPHeaderField: "consumer-key")
            request.setValue("20891a1b4504ddc33d42501f9c8d2215fbe85008", forHTTPHeaderField: "consumer-secret")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            guard let httpBody = try? JSONSerialization.data(withJSONObject: parameterDictionary, options: []) else {
                return
            }
            request.httpBody = httpBody
            
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                
                if let data = data {
                    var erroMsg = ""
                    var response = NSDictionary()
                    
                    do {
                        let json = try JSONSerialization.jsonObject(with: data, options: [])
                        print(json)
                        response = json as! NSDictionary
                    } catch {
                        erroMsg = "Error"
                        print(error)
                    }
                    
                    if ((self.serviceDelegate?.onSuccesofSignupService?(responseDic: response, errormsg: erroMsg, optiona: nil)) != nil) {
                    }
                }
                }.resume()
        }
        else{
            let alert = UIAlertController(title: "", message: "Please check your internet connection", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    //MARK : - SIGNUP Service call
    @objc public func getList(){
        if(reachability?.isReachable)!
        {
            
            let Url = String(format: "https://api.qa.mrhe.gov.ae/mrhecloud/v1.4/api/public/v1/news?local=en")
            guard let serviceUrl = URL(string: Url) else { return }
            
            var request = URLRequest(url: serviceUrl)
            request.httpMethod = "GET"
            request.setValue("mobile_dev_temp", forHTTPHeaderField: "consumer-key")
            request.setValue("20891a1b4504ddc33d42501f9c8d2215fbe85008", forHTTPHeaderField: "consumer-secret")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                
                if let data = data {
                    var erroMsg = ""
                    var response = NSDictionary()
                    
                    do {
                        let json = try JSONSerialization.jsonObject(with: data, options: [])
                        print(json)
                        response = json as! NSDictionary
                    } catch {
                        erroMsg = "Error"
                        print(error)
                    }
                    
                    if ((self.serviceDelegate?.onSuccesofGetList?(responseDic: response, errormsg: erroMsg, optiona: nil)) != nil) {
                    }
                }
                }.resume()
        }
        else{
            let alert = UIAlertController(title: "", message: "Please check your internet connection", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
}
