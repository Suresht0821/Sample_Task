//
//  ViewController.swift
//  Suresh_Task
//
//  Created by Suresh T on 29/08/20.
//  Copyright © 2020 Suresh T. All rights reserved.
//

import UIKit

@objc public protocol SignupDelegate:NSObjectProtocol {
    @objc optional  func onSuccesofSignupService(responseDic : NSDictionary,errormsg :String,optiona : Any?)
}


class ViewController: ServiceEngineClass,ServiceEngineDelegate {
    
    // MARK: - Declarations
    @IBOutlet weak var eidTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var idbarahnoTextField: UITextField!
    @IBOutlet weak var emailIDTextField: UITextField!
    @IBOutlet weak var unifiednumberTextField: UITextField!
    @IBOutlet weak var mobilenoTextField: UITextField!
    
    
    // MARK: - VIEWDIDLOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - SIGNUP BUTTON CLICKED
    @IBAction func signupButtonClicked(_ sender: Any) {
        if eidTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter eid", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
        } else if nameTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        else if idbarahnoTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter idbarahno", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        else if emailIDTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter emailid", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        else if unifiednumberTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter unifiednumber", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        else if mobilenoTextField.text?.count == 0 {
            let alert = UIAlertController(title:"Alert", message: "Please enter mobileno", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        else {
            let signupDcit = NSMutableDictionary.init()
            signupDcit.setValue(eidTextField.text ?? "", forKey: "EID")
            signupDcit.setValue(nameTextField.text ?? "", forKey: "NAME")
            signupDcit.setValue(idbarahnoTextField.text ?? "", forKey: "IDBARHNO")
            signupDcit.setValue(emailIDTextField.text ?? "", forKey: "EMAIL")
            signupDcit.setValue(unifiednumberTextField.text ?? "", forKey: "UNIFIED")
            signupDcit.setValue(mobilenoTextField.text ?? "", forKey: "MOBILENO")
            self.serviceDelegate = self;
            self.callSignUpService(signupDcit)
        }
        
    }

    // MARK: - SUCCESS OR FAILURE RESPONSE
    func onSuccesofSignupService(responseDic : NSDictionary,errormsg :String,optiona : Any?) {
        if errormsg.count == 0 {
            
            let userDefaults = UserDefaults.standard
            userDefaults.setValue("success", forKey: "LOGINDATA")
            userDefaults.setValue(NSNumber(booleanLiteral: true), forKey: "LOGINSUCCESS")
            self.dismiss(animated: true, completion: nil)
            //print(responseDic["message"] as! String)
            let alert = UIAlertController(title:"Alert", message: responseDic["message"] as? String, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            
        }
        
    }


}

